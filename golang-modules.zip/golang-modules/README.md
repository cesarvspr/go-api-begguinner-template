```bash
go build
./golang-modules
```
